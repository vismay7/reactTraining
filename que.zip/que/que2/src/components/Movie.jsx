import { useState } from "react";

const Movie = ({ data }) => {
  const [selectedSeats, setSelectedSeats] = useState([]);
  console.log(data);

  const handleSeatClick = (seat) => {
    if (seat.isBooked) {
      alert("This seat is already booked!");
      return;
    }

    const isAlreadySelected = selectedSeats.some((s) => s.seatNumber === seat.seatNumber);
    if (isAlreadySelected) {
      setSelectedSeats(selectedSeats.filter((s) => s.seatNumber !== seat.seatNumber));
    } else {
      setSelectedSeats([...selectedSeats, seat]);
    }
  };

  return (
    <div>
      <h1>{data.MovieName}</h1>
      <table>
        <tbody>
          {data.Rows.map((row) => (
            <tr key={row.row}>
              {Array.from({ length: 10 }, (_, i) => i + row.Start).map((seatNumber) => {
                return (
                  <td
                    key={seatNumber}
                    style={{
                      backgroundColor: row.AlreadyBooked.includes(seatNumber)
                        ? "grey"
                        : selectedSeats.some((s) => s.seatNumber === seatNumber)
                        ? "blue"
                        : "white",
                      cursor: row.AlreadyBooked.includes(seatNumber) ? "default" : "pointer",
                    }}
                    onClick={() => handleSeatClick({ seatNumber, isBooked: row.AlreadyBooked.includes(seatNumber) })}
                  >
                    {seatNumber}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Movie;
