import React, { useState } from "react";
import Movie from "./components/Movie";

const getSeatsForRows = (rows) => {
  const seats = [];

  rows.forEach((row) => {
    for (let i = row.Start; i <= row.End; i++) {
      seats.push({
        seatNumber: i,
        isBooked: row.AlreadyBooked.includes(i),
      });
    }
  });

  return seats;
};

const App = () => {
  const data = {
    BasicPrice: 300,
    MovieName: "Dhamaka",
    Rows: [
      { row: 1, Start: 1, End: 10, AlreadyBooked: [2, 3, 5] },
      { row: 2, Start: 11, End: 15, AlreadyBooked: [12, 14] },
      { row: 3, Start: 16, End: 20, AlreadyBooked: [17, 20] },
      { row: 4, Start: 21, End: 30, AlreadyBooked: [22, 25] },
      { row: 5, Start: 31, End: 40, AlreadyBooked: [33, 36, 38] },
      { row: 6, Start: 41, End: 45, AlreadyBooked: [42, 44] },
    ],
  };

  const seats = getSeatsForRows(data.Rows);
  const rows = [];

  for (let i = 0; i < seats.length; i += 10) {
    const rowSeats = seats.slice(i, i + 10);
    rows.push({ rowNumber: rows.length + 1, seats: rowSeats });
  }

  return (
    <div>
      <Movie data={data} />
    </div>
  );
};

export default App;
