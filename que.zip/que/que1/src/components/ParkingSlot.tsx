import React, { useState } from "react";
import Form from "./Form";

export type Data = { id: number; carNum: string; time: string };

const ParkingSlot = () => {
  const [data, setData] = useState<Data[]>([]);
  const [pop, setPop] = useState<boolean>(false);
  const [id, setId] = useState<number>();

  const handleClick = (e: React.MouseEvent<HTMLDivElement>) => {
    setId(parseInt((e.target as HTMLDivElement).id));
    setPop(true);
  };

  return (
    <>
      {pop ? (
        <Form setPop={setPop} id={id} setData={setData} data={data} />
      ) : (
        <>
          <div className="parking">
            {Array.from({ length: 20 }, (_, i) => i + 1).map((e) => (
              <div key={e} className={`parking-slot ${data.find((e1) => e1.id == e) ? "green" : ""}`} id={`${e}`} onClick={(e) => handleClick(e)}>
                {data.find((e1) => e1.id == e) ? `car number:- ${data.find((e1) => e1.id == e)?.carNum} time:- ${data.find((e1) => e1.id == e)?.time}` : `${e}`}
              </div>
            ))}
          </div>
        </>
      )}
    </>
  );
};

export default ParkingSlot;
