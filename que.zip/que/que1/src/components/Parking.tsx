import React, { useState } from "react";
import ParkingSlot from "./ParkingSlot";

const Parking = () => {
  return <ParkingSlot />;
};

export default Parking;
