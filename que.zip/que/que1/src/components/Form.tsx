import React, { FC, useState } from "react";
import { Data } from "./ParkingSlot";

type FormProp = {
  setPop: (active: boolean) => void;
  id?: number;
  data?: Data[];
  setData: React.Dispatch<React.SetStateAction<Data[]>>;
};

const Form: FC<FormProp> = ({ setPop, id, setData, data }) => {
  const [carNum, setcarNum] = useState<string>();
  const [time, setTime] = useState<string>();

  const handleSubmit = (e: React.MouseEvent<HTMLButtonElement>) => {
    let carData = { id: id, carNum: carNum, time: time };
    setData((preData: any) => {
      let newData = [...preData, carData];
      console.log(newData);
      return newData;
    });
    setPop(false);
  };

  const handleOut = (e: React.MouseEvent<HTMLButtonElement>) => {
    let car = data?.find((e) => e.id == id);
    let date = new Date();
    let spendTime = `${Math.abs(date.getHours() - parseInt(car?.time.split(":")[0]!))}:${Math.abs(date.getMinutes() - parseInt(car?.time.split(":")[1]!))}`;

    let costsHr = parseInt(spendTime.split(":")[0]);

    {
      costsHr < 1 ? alert("Your parking costs was 20") : costsHr > 2 && costsHr < 4 ? alert("Your parking costs was 40") : costsHr > 4 && costsHr < 6 ? alert("Your parking costs was 100") : costsHr > 6 && costsHr < 8 ? alert("Your parking costs was 200") : alert(`Your parking costs was ${costsHr * 25}`);
    }

    let newData = data?.filter((e) => e.id != id);
    setData(newData!);
    setPop(false);
  };

  return (
    <div>
      <input type="text" id="card" onChange={(e) => setcarNum(e.target.value)} />
      <input type="time" id="time" onChange={(e) => setTime(e.target.value)} />
      <button onClick={(e) => handleSubmit(e)}>IN</button>
      <button onClick={(e) => handleOut(e)}>Out</button>
    </div>
  );
};

export default Form;
