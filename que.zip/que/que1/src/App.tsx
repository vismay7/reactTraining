import React from "react";
import Parking from "./components/Parking";
import "./App.css";

function App() {
  return <Parking />;
}

export default App;
