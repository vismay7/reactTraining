export interface FilterInterface {
  Director: string[];
  Movies: [
    {
      MovieID: number;
      MovieName: string;
    }
  ];
  Actors: string[];
}

export interface MoviesDetailsInterface {
  MovieID: number;

  MovieName: string;

  Details: {
    DirectorName: string;

    ActorsNames: string[];

    VideoLink: string;
  };
}
