import axios from "axios";
import { useEffect, useState } from "react";
import "./App.css";
import Actors from "./components/Actors";
import Director from "./components/Director";
import Movies from "./components/Movies";
import Player from "./components/Player";
import { FilterInterface, MoviesDetailsInterface } from "./Interfaces/Interface";

function App() {
  const [filter, setFilter] = useState<FilterInterface | {}>({});
  const [moviesDetails, setMoviesDetails] = useState<MoviesDetailsInterface[]>([]);
  const [movieId, setMovieId] = useState<number | null>(null);

  useEffect(() => {
    let getData = async () => {
      let fl = await (await axios.get("/Filter.json")).data;
      setFilter(fl);
      let md = await (await axios.get("/MoviesDetail.json")).data;
      setMoviesDetails(md);
    };
    getData();
  }, []);
  return (
    <div className="bg-[#F54B64] h-[100vh] ">
      <div className="grid gap-[2rem] mx-[1rem]">
        <div className="bg-slate-800 text-white text-center text-3xl my-[2rem] p-[2rem]  rounded-3xl">
          <Director moviesDetails={moviesDetails} movieId={movieId!} />
        </div>
        <div className="grid grid-cols-6">
          <div className="bg-slate-600 rounded-lg px-[0.5rem]">
            <Movies moviesDetails={moviesDetails} setMovieId={setMovieId} />
          </div>
          <div className="player col-span-4">
            <Player moviesDetails={moviesDetails} movieId={movieId!} />
          </div>
          <div className="bg-slate-600 rounded-lg p-[1rem]">
            <Actors moviesDetails={moviesDetails} movieId={movieId!} />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
