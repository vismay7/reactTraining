import React, { FC } from "react";
import { MoviesDetailsInterface } from "../Interfaces/Interface";
type PlayerProps = {
  moviesDetails: MoviesDetailsInterface[];
  movieId: number;
};

const Player: FC<PlayerProps> = ({ moviesDetails, movieId }) => {
  let videoLink = moviesDetails.find((e) => e.MovieID == movieId)?.Details.VideoLink;
  return <div>{videoLink ? <video className="w-100" controls src={videoLink} /> : "Please Select Movie"}</div>;
};

export default Player;
