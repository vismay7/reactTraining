import React, { FC } from "react";
import { MoviesDetailsInterface } from "../Interfaces/Interface";
type ActorsProps = {
  moviesDetails: MoviesDetailsInterface[];
  movieId: number;
};

const Actors: FC<ActorsProps> = ({ moviesDetails, movieId }) => {
  let actors = moviesDetails.find((e) => e.MovieID == movieId)?.Details.ActorsNames;
  return (
    <ul>
      {actors?.map((e) => (
        <li className="list-decimal my-2" key={crypto.randomUUID()}>
          {e}
        </li>
      ))}
    </ul>
  );
};

export default Actors;
