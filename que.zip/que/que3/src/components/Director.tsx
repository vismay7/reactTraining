import React, { FC } from "react";
import { MoviesDetailsInterface } from "../Interfaces/Interface";

type DirectorProps = {
  moviesDetails: MoviesDetailsInterface[];
  movieId: number;
};

const Director: FC<DirectorProps> = ({ moviesDetails, movieId }) => {
  let directorName = moviesDetails.find((e) => e.MovieID == movieId)?.Details.DirectorName || "Director Name";
  return <div>{directorName}</div>;
};

export default Director;
