import React, { FC } from "react";
import { MoviesDetailsInterface } from "../Interfaces/Interface";

type MoviesProps = {
  moviesDetails: MoviesDetailsInterface[];
  setMovieId: (valuel: number) => void;
};

const Movies: FC<MoviesProps> = ({ moviesDetails, setMovieId }) => {
  return (
    <>
      {moviesDetails?.map((e) => (
        <div key={e.MovieID} className=" my-[2rem] rounded hover:cursor-pointer bg-slate-900">
          <p className="text-white text-center m-[0.1rem]" onClick={() => setMovieId(e.MovieID)}>
            {e.MovieName}
          </p>
        </div>
      ))}
    </>
  );
};

export default Movies;
