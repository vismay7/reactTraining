import { FC } from "react";
import FamilyInterface from "../Interface/Tree";

type TreeProps = {
  familyData: FamilyInterface[];
};

const Tree: FC<TreeProps> = ({ familyData }) => {
  console.log(familyData);

  return (
    <>
      <ul>
        {familyData?.map((e) => (
          <li key={e.name}>
            {e.name}
            {e.children && <Tree familyData={e.children} />}
          </li>
        ))}
      </ul>
    </>
  );
};

export default Tree;
