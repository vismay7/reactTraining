export default interface FamilyInterface {
  name?: string;
  children?: FamilyInterface[];
}
