import axios, { AxiosResponse } from "axios";
import FamilyInterface from "../Interface/Tree";

export const getData = async (): Promise<FamilyInterface[]> => {
  const res: AxiosResponse<FamilyInterface[]> = await axios.get("/data.json");
  return res.data;
};
