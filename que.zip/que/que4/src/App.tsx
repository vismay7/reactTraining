import { useEffect, useState } from "react";
import Tree from "./Components/Tree";
import FamilyInterface from "./Interface/Tree";
import { getData } from "./Services/Family";

function App() {
  const [familyData, setFamilyData] = useState<FamilyInterface[]>();

  useEffect(() => {
    let fetchData = async () => {
      const data = await getData();
      setFamilyData(data);
    };
    fetchData();
  }, []);

  return (
    <>
      <Tree familyData={familyData!} />
    </>
  );
}

export default App;
