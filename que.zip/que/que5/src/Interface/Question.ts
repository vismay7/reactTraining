export interface QuetionInterface {
  QuestionID: number;
  Description: string;
  Options: string[];
  Answer: string;
}

export interface UserAnsInterface {
  QuestionID: number;
  Answer: boolean;
}
