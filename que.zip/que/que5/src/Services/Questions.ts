import axios, { AxiosResponse } from "axios";
import { QuetionInterface } from "../Interface/Question";

const getQuestion = async (): Promise<QuetionInterface[]> => {
  let res: AxiosResponse<QuetionInterface[]> = await axios.get("/data.json");
  return res.data;
};

export default getQuestion;
