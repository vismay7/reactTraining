import React, { useEffect, useState } from "react";
import Exam from "./Components/Exam";
import { QuetionInterface } from "./Interface/Question";
import getQuestion from "./Services/Questions";

const App = () => {
  const [que, setQue] = useState<QuetionInterface[]>();

  useEffect(() => {
    const fetchQue = async () => {
      let data = await getQuestion();
      setQue(data);
    };
    fetchQue();
  }, []);

  return <Exam questions={que!} />;
};

export default App;
