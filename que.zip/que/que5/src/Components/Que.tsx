import React, { FC, useRef, useState } from "react";
import { QuetionInterface } from "../Interface/Question";
import Test from "./test";

const Que: FC<{ questions: QuetionInterface[] }> = ({ questions }) => {
  const [userAns, setUserAns] = useState();

  const handleSubmit = () => {
    console.log("first");
  };

  return (
    <>
      <div>
        {questions.map((que) => (
          <Test key={crypto.randomUUID()} que={que} />
        ))}
      </div>
      <button type="submit" onClick={() => handleSubmit()}>
        Submit
      </button>
    </>
  );
};

export default Que;
