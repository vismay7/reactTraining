import React, { FC, useState } from "react";
import { QuetionInterface } from "../Interface/Question";
import Que from "./Que";

const Exam: FC<{ questions: QuetionInterface[] }> = ({ questions }) => {
  const [examStart, setExamStart] = useState<boolean>(false);

  setTimeout(() => {
    setExamStart(false);
  }, 20000);

  return (
    <>
      {examStart ? (
        <Que questions={questions} />
      ) : (
        <div>
          <button onClick={(e) => setExamStart(true)}>Start</button>
        </div>
      )}
    </>
  );
};

export default Exam;
