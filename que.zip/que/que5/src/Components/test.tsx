import React from "react";

const Test = ({ que }: any) => {
  const handleAns = (e: React.ChangeEvent<HTMLInputElement>, queId: number) => {
    console.log(e.target.value);
  };

  return (
    <div key={que.QuestionID}>
      <p>{que.Description}</p>
      {que.Options.map((opt: any) => (
        <label key={crypto.randomUUID()}>
          <input type="radio" name={`${que.QuestionID}`} value={opt} onChange={(e) => handleAns(e, que.QuestionID)} />
          {opt}
        </label>
      ))}
    </div>
  );
};

export default Test;
